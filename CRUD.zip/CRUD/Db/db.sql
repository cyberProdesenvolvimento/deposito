
CREATE DATABASE distribuicao

use distribuicao;

CREATE TABLE distribuidor (
	id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	name VARCHAR (50) NOT NULL,

);