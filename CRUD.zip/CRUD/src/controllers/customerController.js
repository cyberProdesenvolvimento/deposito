
const controller = {};

controller.index = (req, res)=>{
	req.getConnection((err, conn)=>{
		conn.query('SELECT * FROM distribuidor', (err, tabela)=>{
			if(err){
				res.json(err);
			}
			res.render('index', {
				data: tabela
			}); 
		});
	});
};
controller.list = (req, res)=>{
	req.getConnection((err, conn)=>{
		conn.query('SELECT * FROM distribuidor', (err, tabela)=>{
			if(err){
				res.json(err);
			}
			res.render('customers', {
				data: tabela
			});
		});
	});
};
controller.save = (req, res)=>{
	let data = req.body; 
	req.getConnection((err, conn)=>{
		conn.query('INSERT INTO distribuidor set ?', [data], (err, tabela)=>{
			//res.send('Produto salvo com Sucesso!');
			res.redirect('/admin');
		});
	});
	
};
controller.inserir = (req, res)=>{
	let dados = {
		codigo: req.body.codigo,
		cliente: req.body.cliente,
		endereco: req.body.endereco,
		pedido: req.body.pedido,
		data: req.body.data,
		status: req.body.status,
		pagamento: req.body.pagamento,
		status_entregador:req.body.status_entregador 
	}  
	
	req.getConnection((err, conn)=>{
		conn.query('INSERT INTO pedidos set ?', [dados], (err, tabela)=>{
			if(err){
				res.json(err);
			}else{
				res.send("ok");
			}
		});
	});
	
};
controller.delete = (req, res)=>{
	//let id = req.params.id;
	let { id } = req.params;
	req.getConnection((err, conn)=>{
		conn.query('DELETE FROM distribuidor WHERE id = ?', [id], (err, rows)=>{
			res.redirect('/admin');
		});
	});
};	

controller.edit = (req, res)=>{
	//let id = req.params.id;
	let { id } = req.params;
	req.getConnection((err, conn)=>{
		conn.query('SELECT * FROM distribuidor WHERE id = ?', [id], (err, tabela)=>{
			res.render('customer_edit', {
				data: tabela[0]
			});
		});
	});
};
controller.update = (req, res)=>{
	let { id } = req.params; 
	let newdata = req.body;
	req.getConnection((err, conn)=>{
		conn.query('UPDATE distribuidor set ? WHERE id = ?', [newdata, id], (err, tabela)=>{
			console.log(tabela);
			//res.send('Produto salvo com Sucesso!');
			res.redirect('/admin');
		});
	});
	
};
controller.pedidos = (req, res)=>{
	
	req.getConnection((err, conn)=>{
		conn.query('SELECT * FROM pedidos ORDER BY id DESC', (err, tabela)=>{
			if(err){
				res.json(err);
			}else{
				res.render('pedidos', {
					data: tabela
				});
			}
			
		});
	});
};
controller.status = (req, res)=>{
	//let id = req.params.id;
	let id = req.body.id;
	req.getConnection((err, conn)=>{
		conn.query('SELECT * FROM pedidos WHERE id = ?', [id], (err, tabela)=>{
			if(err){
				res.json(err);
			}else{
				res.send(tabela[0]);
			}
		});
	});
};
controller.entrega = (req, res)=>{
	let id = req.body.id;
	let newdata = "FECHADO";
	req.getConnection((err, conn)=>{
		conn.query('UPDATE pedidos SET status = ? WHERE id = ?', [newdata, id], (err, tabela)=>{
			if(err){
				res.json(err);
			}else{
				res.send("Enviado pelo entregador");
			}
		});
	});
	
};
controller.deletepedido = (req, res)=>{
	let id = req.body.id;
	req.getConnection((err, conn)=>{
		conn.query('DELETE FROM pedidos WHERE id = ?', [id], (err, rows)=>{
			if(err){
				res.json(err);
			}else{
				res.send("Pedido excluido com sucesso");
			}
		});
	});
};
controller.estoque = (req, res)=>{//teste
	let id = req.body.id;
	let newdata = "FECHADO";
	req.getConnection((err, conn)=>{
		conn.query('UPDATE distribuidor SET qtd = ? WHERE id = ?', [newdata, id], (err, tabela)=>{
			if(err){
				res.json(err);
			}else{
				res.send("Estoque atualizado!");
			}
		});
	});
	
};
module.exports = controller;