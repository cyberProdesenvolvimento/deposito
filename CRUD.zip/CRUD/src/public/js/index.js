$(document).ready(function() { 
	
	$('#carrinho').on('click', function(event) {//troca o ponto pela virgula no total
		event.preventDefault();
		$('#total').text('R$ '+total().toFixed(2).replace('.',','));
	});
	$('#mais').on('click', function(event) {//acrecenta uma unidade ao item
		event.preventDefault();
		var soma = 0;
		soma+= parseFloat($('#qtd').text()) +2; 
		$('#qtd').text(soma);
		soma =0;
	});
	$('#menos').on('click', function(event) {//diminui uma unidade ao item
		event.preventDefault();
		var soma = 0;
		soma+= parseFloat($('#qtd').text()) -1;
		if (soma > 0) {
			$('#qtd').text(soma);
		}
		soma =0;
	});
	function alertas(tipo){
		if(tipo ==="adiciona item ao carrinho"){
				const toast = swal.mixin({
			  		toast: true,
			 		showConfirmButton: false,
			  		timer: 1500
				});
					toast({
	  				type: 'success',
	  				title: 'Item Adicionado ao Carrinho!'
	  			})
		}else if(tipo === "escolha o complemento"){
				const toast = swal.mixin({
			  		toast: true,
			 		showConfirmButton: false,
			  		timer: 2000
				});
					toast({
	  				type: 'info',
	  				title: 'Escolha um complemento!'
				})
		}else if(tipo === "escolha o espetinho"){
				const toast = swal.mixin({
			  		toast: true,
			 		showConfirmButton: false,
			  		timer: 2000
				});
					toast({
	  				type: 'info',
	  				title: 'Escolha o espetinho!'
				})
		}else if (tipo === "adicione itens no carrinho"){
			swal({
			  showConfirmButton: false,
			  title: " Adicione Itens ao Carrinho!",
			  text: "Obrigado.",
			  type: "error",
			  timer: 2000,
			});
		}
		else if(tipo === "entrega"){
			const toast = swal.mixin({
			  		toast: true,
			 		showConfirmButton: true,
			  		//timer: 2000
				});
					toast({
	  				type: 'info',
	  				title: 'Só entregamos a partir de 3 unidades!'
				})
		}
	}
	var Pedido = {};
	Pedido.item = function(url_img, produto, qtd, preco){
		var self = this;
			self.url_img = url_img;
			self.produto = produto;
			self.qtd = qtd;
			self.valor = valor;
	};
	Pedido.endereco = function(){
		var get_endereco = new Array;
		this.get = function(){
			 get_endereco[0] = localStorage.getItem('rua');
             get_endereco[1] = localStorage.getItem('numero');
             get_endereco[2] = localStorage.getItem('bairro');
             get_endereco[3] = localStorage.getItem('proximo');
             return get_endereco;
		}
		this.set = function(rua, numero, bairro, proximo){
			localStorage.setItem('rua',rua);
          	localStorage.setItem('numero',numero);
          	localStorage.setItem('bairro',bairro);
          	localStorage.setItem('proximo',proximo);
		}
	}
	Pedido.itensPedido = function(){
		var self = this;
		var lista_de_pedidos = new Array;

		self.addPedidos = function(url_img, produto, descricao, unidade, qtd, preco){
			lista_de_pedidos.push(new Pedido.item(url_img, produto, descricao, unidade, qtd, preco));
			return lista_de_pedidos;
		}
		self.item = function(url_img, produto, qtd, preco){
				var valor = qtd*preco;
				var cols = "";
				cols+= '<tr class="filtra_tr">';
				cols+= '<th><img style="width: 50px; height: 50px;"  src="'+url_img+'" alt="Card image" class="rounded-0"></th>';
				cols+= '<td class="produto"><small>'+produto+'</small></td>';
				//cols+= '<td class="descricao"><small>'+descricao+'</small></td>';
				cols+= '<td class="qtd">'+qtd+'</td>';
				cols+= '<td class="val">'+valor.toFixed(2).replace('.',',')+'</td>';
				cols+='<th><div class="btn-group-vertical">';
				cols+='<a href="#" onclick="adiciona(this)" class="waves-effect" data-valor="'+preco+'">';
				cols+='<h2 class=" badge badge-success waves-effect"><i class="fa fa-plus" aria-hidden="true"></i></h2></a>';
			    cols+='<a href="#" onclick="subtrai(this)" class="waves-effect valor" data-valor="'+preco+'"><h2 class="badge badge-danger waves-effect"><i class="fa fa-minus" aria-hidden="true"></i></h2></a></div></th>';                            
				cols+= '</tr>';
				$('#tabela').append(cols);
			    $('#qtd-carrinho').text(parseFloat($('#qtd-carrinho').text()) + parseFloat(qtd));
			    var taxa = parseFloat($('#taxa').text().slice(3).replace(',','.'));
			    $('#subtotalentrega').text('R$ '+total(taxa).toFixed(2).replace('.',','));
				return false;
		}		
	}
	$('#adicionar').on('click', function(event) {//adiciona itens no carrinho
		event.preventDefault();
		var produto = $('#produto').text();
		var adicionar_pedidos = new Pedido.itensPedido();
		var a = [];
			a.push($('#url').attr('src'));
			a.push(produto);
			a.push($('#qtd').text());
			a.push(parseFloat($('#valor').text().slice(3).replace(',','.')));
		switch (produto){
			case  "Água Cristalina - 20L":
					adicionar_pedidos.item(a[0], a[1], a[2], a[3]);
					$('#qtd').text('1');
					$('#detalhes').modal('hide');
					a = [];
				    alertas('adiciona item ao carrinho');
			    break;
			case "Água Buriti - 20L":
					adicionar_pedidos.item(a[0], a[1], a[2], a[3]);
					$('#qtd').text('1');
					$('#detalhes').modal('hide');
					a = [];
					alertas('adiciona item ao carrinho');
			    break;
			default:
		};
	});
	//envia pedido
	$('.ver-ocultar').click(function(event) { 
		$('#navbarSupportedContent').toggle('slow');
	});
	$('li.ocultar').click(function(event) { 
		$("#espetinhosLista li.add, #bebidasLista li.add, #porcoesLista li.add").css("display", "block");
	});
	//inicio abrir menu
	$('#open').click(function(event) {
		$("#espetinhosLista li.add, #bebidasLista li.add, #porcoesLista li.add").css("display", "block");
		$('#navbarSupportedContent').toggle('slow');
	});
(function($){//remover item dos meu pedidos 
	adiciona = function(item){
		    var tr = $(item).closest('tr');
		    var valor = tr.find('th a').attr('data-valor');
		  	var val = 0;	
			var qtd = 0;
			var tot = 0;
			qtd = parseFloat(tr.find('td.qtd').text()) +1;
			val = parseFloat(valor);
			tot = qtd * val;
			tr.find('td.qtd').text(qtd);
			tr.find('td.val').text(tot.toFixed(2).replace('.',','));
			$('#total').text("R$ "+total().toFixed(2).replace('.',','));
			$('#qtd-carrinho').text(parseFloat($('#qtd-carrinho').text()) + 1);
			var taxa = parseFloat($('#taxa').text().slice(3).replace(',','.'));
	        $('#subtotalentrega').text('R$ '+total(taxa).toFixed(2).replace('.',','));
	        
		return false;
	}	
})(jQuery);
(function($){//remover item dos meu pedidos
	subtrai = function(item){
	    var tr = $(item).closest('tr');
	    var valor = tr.find('th a').attr('data-valor');
	  	var val = 0;	
		var qtd = 0;
		var tot = 0;
		qtd = parseFloat(tr.find('td.qtd').text()) -1;
		val = parseFloat(valor);
		if (qtd === 0) {
			swal({
			  title: "Atenção!",
			  text: "Deseja Realmente Excluir este Item?",
			  type: "question",
			  showCancelButton: true,
			  cancelButtonText:"Cancelar",
			  confirmButtonColor: '#3085d6',
			  cancelButtonColor: '#d33',
			  confirmButtonText: 'Sim, Excluir!'
			})
			.then((result) => {
			  if (result.value) {
			  	var toti = 0;	
				var a = 0;
					tr.fadeOut('400', function() {
						toti = tr.find('td.val').text();
						tr.remove();
						 a = parseFloat($('#total').text().slice(3).replace(',', '.')) - parseFloat(valor);
						 $('#total').text('R$ '+ a.toFixed(2).replace('.', ','));
						 $('#qtd-carrinho').text(parseFloat($('#qtd-carrinho').text()) - 1);
						 var taxa = parseFloat($('#taxa').text().slice(3).replace(',','.'));
                         $('#subtotalentrega').text('R$ '+total(taxa).toFixed(2).replace('.',','));
					  });
			    const toast = swal.mixin({
			  		toast: true,
			 		showConfirmButton: false,
			  		timer: 2000
				});
					toast({
	  				type: 'success',
	  				title: 'Item excluido com Sucesso!'
				})
			  }else{
			  	tr.find('td.qtd').text(qtd +1);
			  }
			});
		}else{
			tot = qtd * val;
			tr.find('td.qtd').text(qtd);
			tr.find('td.val').text(tot.toFixed(2).replace('.',','));
			$('#total').text('R$ '+total().toFixed(2).replace('.',','));
			$('#qtd-carrinho').text(parseFloat($('#qtd-carrinho').text()) - 1);
			var taxa = parseFloat($('#taxa').text().slice(3).replace(',','.'));
            $('#subtotalentrega').text('R$ '+total(taxa).toFixed(2).replace('.',','));
		}
	return false;
	}	
})(jQuery);
$('#concluir').on('click', function(event) {//processo de conclusão do pedido
	var a = $('#tabela').find('.filtra_tr');
	var condicao_entrega = 0;
	for (var i = 0; i < a.length; i++) {
		condicao_entrega =condicao_entrega + parseFloat($(a[i]).find('td.qtd').text());
	}
	if (a.length !== 0) {
		if (condicao_entrega >= 3) {
			var proximo = "";
			var rua = "";
			var numero ="";
			var bairro ="";
			var entrega_endereco = new Pedido.endereco();
			var valida = entrega_endereco.get()[0];
			console.log(entrega_endereco.get());
			if (valida === null || valida === undefined) {
			}else{
				 rua = entrega_endereco.get()[0];
	             numero = entrega_endereco.get()[1];
	             bairro = entrega_endereco.get()[2];
	             proximo = entrega_endereco.get()[3];
			}
	       	swal.mixin({//dados do endereço
	          llowEscapeKey: false,
	          allowOutsideClick: false,
	          allowEnterKey:false,  
	          input: 'text',
	          confirmButtonText: 'Próximo &rarr;',
	          showCancelButton: true,
	          cancelButtonText:"Cancelar",
	          progressSteps: ['1', '2', '3', '4'],
	          reverseButtons:true,
	          preConfirm:(condicao)=>{
	            if (!condicao) {
	                swal.showValidationError(
	                  `Campo Obrigatório`
	                )
	            }
	          },
	        }).queue([
	          {
	            title: 'Endereço para Entrega',
	            text: 'Obs: Digite o nome de seu rua',
	            inputPlaceholder: 'Nome da  RUA',
	            inputValue: rua,
	          },
	          {
	            title: 'Endereço para Entrega',
	            text: 'Digite o número da rua; apenas numeros',
	            inputPlaceholder: 'Número da CASA',
	            inputValue: numero,
	          },
	          {
	            title: 'Endereço para Entrega',
	            text: 'Digite o nome do Bairro',
	            inputPlaceholder: 'Nome do BAIRRO',
	            inputValue: bairro,
	          },
	          {
	            title: 'Endereço para Entrega',
	            text: 'Digite um ponto de referencia próximo de sua casa.',
	            inputPlaceholder: 'Próximo à ...',
	            inputValue: proximo,
	          }
	        ]).then((result) => {
	          if (result.value) {//condicao para o dados do endereco
	          	entrega_endereco.set(result.value[0],result.value[1],result.value[2],result.value[3]);
	            	var endereco = result.value.toString();
				  	var lista = [];
					var sublista = [];
					for (var i = 0; i < a.length; i++) {
						$(a[i]).find('td').each(function(index, el) {
							if ($(this).is('.produto')) {
								sublista['produto']=$(this).text();
							}
							if ($(this).is('.descricao')) {
								sublista['descricao']=$(this).text();
							}
							if ($(this).is('.qtd')) {
								sublista['qtd']=$(this).text();
							}
							if ($(this).is('.val')) {
								sublista['valor']=$(this).text();
							}
						});
						lista.push(sublista);
						sublista = [];
					}
					sublista['total'] = $('#total').text();
					sublista['endereco'] = endereco;
					lista.push(sublista);
					sublista = [];
					var cod = codigo();
					var conteudoWhatsApp = cod;
					var enviaPedidoLista = [];//variavel que armazena o pedido completo
					enviaPedidoLista.push(cod);
					var enviaPedido = "";//variavel que armazena o pedido
					var link = "https://api.whatsapp.com/send?phone=5589999332646&text=";
					for (var i = 0; i < lista.length; i++) {
						if (lista[i].produto !== undefined) {
							enviaPedido+= lista[i].produto+" - ";
							}
						if (lista[i].descricao !== undefined) {
							enviaPedido+=lista[i].descricao+" - ";
						}
						if (lista[i].qtd !== undefined) {
							enviaPedido+="Qtd: "+lista[i].qtd+" | ";
						}
						if (lista[i].total !== undefined) {
							enviaPedido+= "Total a pagar: "+lista[i].total;
						}
					}
					link += encodeURIComponent("Código do Pedido: "+conteudoWhatsApp);
					enviaPedidoLista.push(localStorage.getItem('cliente'));
					enviaPedidoLista.push(endereco);
					enviaPedidoLista.push(enviaPedido);
					var formapagamento = "";
					swal({
					   title:"Código do Pedido: "+cod,
					   text: "Clique no botão ENVIAR para recebermos o seu código do pedido pelo WhatsApp. ",		
				       /*input: 'radio',
			              inputOptions: {
			                'cartao':'Cartão',
			                'dinheiro':'Dinheiro'
			              },*/
				       allowEscapeKey: false,
				       allowOutsideClick: false,
				       allowEnterKey:false,
				       showConfirmButton: true,
				       confirmButtonText:"ENVIAR",
				       showCancelButton:true,
				       cancelButtonText:"Cancelar",
				       confirmButtonAriaLabel:true,
				       reverseButtons:true,
				       /*inputValidator: (result) => {
			                return !result && 'Oops, escolha a forma de pagamento. '
			           }*/
					})
					.then((result) => {
						if (result.value) {
							//formapagamento = result.value;
							enviaPedidoLista.push(formapagamento);
					        formapagamento = "";
							ajaxPedido(enviaPedidoLista);
							window.open(link,'_blank');
							$('#tabela').find('.filtra_tr').remove();
					        $('#qtd-carrinho').text('0');
					        $('#subtotalentrega').text('');
					        $('#cart-modal-ex').modal('hide');
						}
					});
	          }//fim da condicao para o dados do endereco
	        })//fim dados do endereco 
   		}else{
   			alertas('entrega');
   		}
	}else{
		swal({
		  showConfirmButton: false,
		  title: " Adicione Itens ao Carrinho!",
		  text: "Obrigado.",
		  type: "error",
		  timer: 2000,
		});
		$('#cart-modal-ex').modal('hide');
	} //fim if
});//fim do processo de conclusão do pedido
});
function pedido(url) {
    this.url = url;
    this.cliente = null;
    this.endereco = null;
    this.formaPagamento = null;
    this.observacoes = null;
    this.itensPedido = new Array();
}
function total(taxa){//soma todos os valores dos itens da tabela
	var soma = 0;
	var muilt = 0;
	if (taxa) {
		$("#tabela > tr td.val").each(function(index, el) {
		soma+= parseFloat($(this).text().replace(',','.'));
	    });
		return soma + parseFloat(taxa);
	}else{
		$("#tabela > tr td.val").each(function(index, el) {
		soma+= parseFloat($(this).text().replace(',','.'));
	    });
		return soma;
	}
};
function codigo(max){
	max=(!max||max>3)?3:max;
	var codigo='';
	var letras=['w','x','y','z','f','b','c','k','g','b'];
	var numeracao=Math.random();
	var string=String(numeracao);
	var string=string.split('.');
	var numeros=string[1].split('');
	for (var i = 0; i < max; i++) {
		codigo+=numeros[i]+letras[numeros[i]];
	}
	return codigo;   
}
function ajaxPedido(enviaPedidoLista){
	$.ajax({
		url: 'php/banco.php',
		type: 'POST',
		data: {lista: enviaPedidoLista},
	})
	.fail(function(data) { 
		console.log("error");
		console.log(data);
	})
	.always(function() {
		console.log("completado");
	});
}
