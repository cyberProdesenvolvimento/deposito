$("#status-pedido").click(function(event) {  
        var id = $(".d-id").text();
        var status = $(".d-status").text();
        fechaPedido(id, status);
});
$("")
$('#atualizatabelapedidos').click(function(event) {
     get();
});
$('#entregador').click(function(event) {
  var id = $('.d-id').text();
  var numero = $("#DropdownMenu").attr('data-whatsappentregador');
  var valida = $("#DropdownMenu").text();
    if ( valida === "Escolha o Entregador") {
        const toast = swal.mixin({
          toast: true,
          showConfirmButton: false,
          timer: 2000
        });
          toast({
            type: 'info',
            title: 'Escolha o Entregador!'
        })
    }else{
      Entrega(numero);
      status_entregador(id);
    }
});
function Entrega(numero_whatsapp){
  var link ="https://api.whatsapp.com/send?phone="+numero_whatsapp+"&text=";
  console.log(numero_whatsapp);
  var valida = localStorage.getItem('pedido-entrega');
  var conteudoWhatsApp = "";
  if (valida === null || valida === undefined) {

  }else{
      conteudoWhatsApp+="*NOVA ENTREGA*\n"+"__________________________________"+"\n'";
      conteudoWhatsApp+="*Cliente* : _"+localStorage.getItem('cliente-entrega')+"_\n";
      conteudoWhatsApp+="*Pedido*:_"+localStorage.getItem('pedido-entrega')+"_\n"+"__________________________________"+"\n'"
      conteudoWhatsApp+="*Endereço* :_"+localStorage.getItem('endereco-entrega')+"_";
      link += encodeURIComponent(conteudoWhatsApp);
      window.open(link,'_blank');
      $('#modalPoll').modal('hide');
      console.log(conteudoWhatsApp);
  }
}
function Entregador(item){
  var a = $(item).closest('a');
  var nome_entregador = a.text();
  var whatsapp_entregador = a.attr('data-whatsappentregador');
  $('#DropdownMenu').text(nome_entregador);
  $('#DropdownMenu').attr('data-whatsappentregador', whatsapp_entregador);
} 
function deletar(elemento){
    var tr = $(elemento).closest('tr');
    var id = $(tr).find('td.id-table').text();
    swal({
            title: "Atenção!",
            text: "Deseja Realmente Excluir este Item?",
            type: "question",
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sim, Excluir!'
        })
        .then((result) => {
          if (result.value) {
                $.ajax({
                    url: 'php/delete.php',
                    type: 'GET',
                    data: {id: id},
                })
                .done(function() {
                    console.log("success");
                })
                .fail(function() {
                    console.log("error");
                })
                .always(function() {
                    console.log("complete");
                    const toast = swal.mixin({
                      toast: true,
                      showConfirmButton: false,
                      timer: 2000
                    });
                      toast({
                        type: 'success',
                        title: 'Item Excluido com Sucesso!'
                    })
                    get();
                });
            }//fim if
        });
}//f-delete
function fechaPedido(id, status){
   if (status === "ABERTO") {
        $.ajax({
            url: 'php/atualiza.php',
            type: 'GET',
            data: {id:id},
        })
        .done(function() {
            console.log("success");
        })
        .fail(function() {
            console.log("error");
        })
        .always(function() {
            console.log("complete");
            get();
            const toast = swal.mixin({
              toast: true,
              showConfirmButton: false,
              timer: 2000
            });
              toast({
                type: 'success',
                title: 'Pedido Fechado com Sucesso!'
            })
        });
   }else if (status === "FECHADO") {
      const toast = swal.mixin({
        toast: true,
        showConfirmButton: false,
        timer: 2000
      });
        toast({
          type: 'info',
          title: 'Pedido já Fechado!'
      })
   } 
}//f-fecharpedido
function status_entregador(id){
    if (id) {
        $.ajax({
            url: 'php/status_entrega.php',
            type: 'GET',
            data: {id:id},
        })
        .done(function() {
            console.log("success");
        })
        .fail(function() {
            console.log("error");
        })
        .always(function() {
            console.log("complete");
            get();
            const toast = swal.mixin({
              toast: true,
              showConfirmButton: false,
              timer: 2000
            });
              toast({
                type: 'success',
                title: 'Pedido enviado ao entregador com Sucesso!'
            })
        });
    }else{

    }
    
}
function get(){//busca os pedidos feitos no dia
  $.getJSON('php/categoria.php', function(json, Status) {
          if (Status === "success" ) {
              $("#tabelapedidos").find('.tr_tab').remove();
              $.each(json, function(i, val) { 
                var item = "<tr class='tr_tab'>";
                    item += '<td class="status-entrega">'+json[i].status_entregador+'</td>';
                    item += '<td class="codigo-table" ><h5 class=" font-weight-bold dark-grey-text">'+json[i].codigo+'</h5></td>';
                    item += '<td class="hour data-table"><small><span class="teal-text"><i class="fa fa-clock-o" aria-hidden="true"></i> '+json[i].data.slice(10)+'</span></small></td>';
                    if (json[i].status === "FECHADO") {
                        item += '<td><span class="tabela-status badge red">'+json[i].status+'</span></td>';
                    }else{
                        item += '<td><span class="tabela-status badge green">'+json[i].status+'</span></td>';
                    }
                    item += '<td><div class="btn-group-vertical"><a onclick=ver(this) class="mb-2 ver btn-sm btn-success"><i class="fa fa-chevron-right px-1"></i></a>';
                    item += '<a onclick=deletar(this) class="excluir btn-sm btn-danger"><i class="fa fa-trash px-1"></i></a></div></td>';
                    item += '<td  class="invisivel id-table">'+json[i].id+'</td>';
                    item += "</tr>";
                $("#tabelapedidos").append(item);
              });
              $('.invisivel').css("display", "block");
              $('.invisivel').css("display", "none");
          }else{
              var item ='<ul><li class="media add my-3 py-0 rgba-white-strong rounded z-depth-1-half">';
              item+='<div class="col-md-12  media rgba-white-strong rounded justify-content-between px-1 py-0">';
              item+='<p class="produto mt-1 mb-0 teal-text font-weight-bold align-self-star">Não foi possível carregar a lista, Internet lenta</p></div></li></ul>';
              $("#pedidos").append(item);
          }
  });
}//f-get
function ver(elemento){
      var lista = "";
      var total = "";
      var array = [];
      var tr = $(elemento).closest('tr');
      var id = $(tr).find('td.id-table').text();
swal({ 
  onOpen: () => {   
      swal.showLoading()  
      $.getJSON('php/buscaid.php', {id: id}, function(json, Status) {
        $('#DropdownMenu').text('Escolha o Entregador');
          if (Status === "success") {
              $.each(json, function(i, val) {
                  $(".d-cliente").text("Cliente - "+json[i].cliente);
                  $(".d-id").text(json[i].id);
                  $(".d-codigo").text(json[i].codigo);
                  $(".d-data").html('<i class="fa fa-clock-o"></i>  ' +json[i].data.slice(10));
                  if (isNaN(json[i].enderecomesa)) {
                      $(".d-mesa").html('<i class="fa fa-home"></i>  '+json[i].enderecomesa);
                  }else{
                      $(".d-mesa").html('<strong>MESA</strong>  '+json[i].enderecomesa);
                  }
                  if (json[i].status === "FECHADO") {
                      $('span.d-status').removeClass('badge green');
                      $('span.d-status').addClass('badge red');
                      $(".d-status").text(json[i].status);
                  }else{
                      $('span.d-status').removeClass('badge red');
                      $('span.d-status').addClass('badge green');
                      $(".d-status").text(json[i].status);
                  }
                  array = json[i].pedido.split("|");
                  localStorage.setItem('pedido-entrega', json[i].pedido);
                  localStorage.setItem('cliente-entrega', json[i].cliente);
                  localStorage.setItem('endereco-entrega', json[i].enderecomesa);
                  total = array.pop();
                  for (var i = 0; i < array.length; i++) {
                      lista += '<a class=" mx-0 list-group-item list-group-item-action waves-effect">'+array[i];
                      lista +='<i class="fa fa-check px-1"></i></a>';
                  }
              });
                 $("#lista-pedido").html(lista);
                  $(".total").text(total);
                  $('#modalPoll').modal('show');
                  lista = "";
                  total = "";
                  array = [];
                  swal.close()
          }else{
            swal.close()
              swal({
                showConfirmButton: false,
                type: 'error',
                title: 'Oops...',
                text: 'Alguma coisa deu errado!',
                timer: 2000
              })
          }
      });
  }//fim onpen
})//fim sweetalert  
}//f-ver