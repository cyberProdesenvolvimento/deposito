$(document).ready(function() {
	$.ajax({
		url: 'meusPedidos.php',
		type: 'POST',
		data: {lista: enviaPedidoLista},
	})
	.done(function(data) {
		
		verifica = true;
	})
	.fail(function(data) {
		console.log("error");
		console.log(data);
	})
	.always(function() {
		console.log("complete");
		
	});
	
}); 

	
