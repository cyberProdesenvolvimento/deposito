$(document).ready(function() {  
	$('#abri-carrinho').on('click', function(event) {//troca o ponto pela virgula no total
		event.preventDefault();
		var li = $('#lista-pedidos').find('li.lista');
		var lica = $('#lista-pedidos').find('li.carrinho-vazio');
		if (li.length === 0) {
			if (lica.length ==! 0) { 
				lica.remove();
			}
			var cols = "";
			cols+= '<li class="carrinho-vazio list-group-item d-flex justify-content-between align-items-center lh-condensed mx-0">';
			cols+= '<div><h6  class="my-0 text-muted">Adicione Itens ao Carrinho!</h6></div>';
			cols+= '</li>';
			$('#lista-pedidos').append(cols);
		}else{
			$('#lista-pedidos').find('li.carrinho-vazio').remove();
		}
		
		$('#total').text('R$ '+total().toFixed(2).replace('.',','));
	});
	$('#mais').on('click', function(event) {//acrecenta uma unidade ao item
		event.preventDefault();
		var soma = 0;
		soma+= parseFloat($('#qtd').text()) +1; 
		$('#qtd').text(soma);
		soma =0;
	});
	$('#menos').on('click', function(event) {//diminui uma unidade ao item
		event.preventDefault();
		var soma = 0;
		soma+= parseFloat($('#qtd').text()) -1;
		if (soma > 0) {
			$('#qtd').text(soma);
		}
		soma =0;
	});

	var Pedido = {};
	Pedido.item = function(url_img, produto, qtd, preco){
		var self = this;
			self.url_img = url_img;
			self.produto = produto;
			self.qtd = qtd;
			self.valor = valor;
	};
	Pedido.endereco = function(){
		var get_endereco = new Array;
		this.get = function(){
			 get_endereco[0] = localStorage.getItem('cliente');
			 get_endereco[1] = localStorage.getItem('rua');
             get_endereco[2] = localStorage.getItem('numero');
             get_endereco[3] = localStorage.getItem('bairro');
             get_endereco[4] = localStorage.getItem('proximo');
             get_endereco[5] = localStorage.getItem('whatsapp');
             return get_endereco;
		}
		this.set = function(cliente, rua, numero, bairro, proximo, whatsapp){
			localStorage.setItem('cliente',cliente);
			localStorage.setItem('rua',rua);
          	localStorage.setItem('numero',numero);
          	localStorage.setItem('bairro',bairro);
          	localStorage.setItem('proximo',proximo);whatsapp
          	localStorage.setItem('whatsapp',whatsapp);
		}
	}
	Pedido.itensPedido = function(){
		var self = this;
		var lista_de_pedidos = new Array;

		self.addPedidos = function(url_img, produto, descricao, unidade, qtd, preco){
			lista_de_pedidos.push(new Pedido.item(url_img, produto, descricao, unidade, qtd, preco));
			return lista_de_pedidos;
		}
		self.item = function( produto, qtd, preco){
				var valor = qtd*preco;
				var cols = "";
				cols+= '<li class="lista list-group-item d-flex justify-content-between align-items-center lh-condensed mx-0">';
				cols+= '<div><h6  class="my-0 produto">'+produto;
				cols+= '</h6><small class="text-muted">Qunatidade: </small><small class="text-muted qtd">'+qtd+'</small></div>';
				cols+= '<div class="d-flex align-items-end"><span class="text-muted text-success valor">R$ '+valor.toFixed(2).replace('.',',')+'</span></div>';
				cols+='<div class="btn-group-vertical">';
				cols+='<button type="button" onclick="adiciona(this)" class="btn btn-sm btn-success" data-valor="'+preco+'"><i class="fa fa-plus" aria-hidden="true"></i></button>';
				cols+='<button type="button" onclick="subtrai(this)" class="btn btn-sm btn-danger" data-valor="'+preco+'"><i class="fa fa-minus" aria-hidden="true"></i></button>';
				cols+= '</div>';
				cols+= '</li>';
				$('#lista-pedidos').append(cols);
			    $('#qtd-carrinho').text(parseFloat($('#qtd-carrinho').text()) + parseFloat(qtd));
			    //var taxa = parseFloat($('#taxa').text().slice(3).replace(',','.'));
			    var taxa = 2.0;
			    $('#subtotalentrega').text('R$ '+total(taxa).toFixed(2).replace('.',','));
				return false;
		}		
	}
	$('#adicionar').on('click', function(event) {//adiciona itens no carrinho
		event.preventDefault();
		var produto = $('#nome-produto').text();
		var adicionar_pedidos = new Pedido.itensPedido();
		var a = [];
			a.push(produto);
			a.push($('#qtd').text());
			a.push(parseFloat($('#valor').text().slice(3).replace(',','.')));
		switch (produto){
			case  "Água Cristalina - 20L":
					adicionar_pedidos.item(a[0], a[1], a[2]);
					$('#qtd').text('1');
					$('#detalhes').modal('hide');
					a = [];
				    alertas('adiciona item ao carrinho');
			    break;
			case "Água Buriti - 20L":
					adicionar_pedidos.item(a[0], a[1], a[2]);
					$('#qtd').text('1');
					$('#detalhes').modal('hide');
					a = [];
					alertas('adiciona item ao carrinho');
			    break;
			default:
		};

	});
(function($){//remover item dos meu pedidos 
adiciona = function(item){
	    var li = $(item).closest('li');
	    var valor = li.find('button').attr('data-valor');
	  	var val = 0;	
		var qtd = 0;
		var tot = 0;
		qtd = parseFloat(li.find('.qtd').text()) +1;
		val = parseFloat(valor);
		tot = qtd * val;
		li.find('.qtd').text(qtd);
		li.find('.valor').text("R$ "+tot.toFixed(2).replace('.',','));
		$('#total').text("R$ "+total().toFixed(2).replace('.',','));
		$('#qtd-carrinho').text(parseFloat($('#qtd-carrinho').text()) + 1);
		//var taxa = parseFloat($('#taxa').text().slice(3).replace(',','.'));
		var taxa = 2;
        $('#subtotalentrega').text('R$ '+total(taxa).toFixed(2).replace('.',','));
        
	return false;
}	
})(jQuery);
(function($){//remover item dos meu pedidos
	subtrai = function(item){
	    var li = $(item).closest('li');
	    var valor = li.find('button').attr('data-valor');
	  	var val = 0;	
		var qtd = 0;
		var tot = 0;
		qtd = parseFloat(li.find('.qtd').text()) -1;
		val = parseFloat(valor);
		if (qtd === 0) {
			swal({
			  title: "Atenção!",
			  text: "Deseja Realmente Excluir este Item?",
			  type: "question",
			  showCancelButton: true,
			  cancelButtonText:"Cancelar",
			  confirmButtonColor: '#3085d6',
			  cancelButtonColor: '#d33',
			  confirmButtonText: 'Sim, Excluir!'
			})
			.then((result) => {
			  if (result.value) {
			  	var toti = 0;	
				var a = 0;
					li.fadeOut('400', function() {
						toti = li.find('.valor').text();
						li.remove();
						 a = parseFloat($('#total').text().slice(3).replace(',', '.')) - parseFloat(valor);
						 $('#total').text('R$ '+ a.toFixed(2).replace('.', ','));
						 $('#qtd-carrinho').text(parseFloat($('#qtd-carrinho').text()) - 1);
						 //var taxa = parseFloat($('#taxa').text().slice(3).replace(',','.'));
						 var taxa = 2;
                         $('#subtotalentrega').text('R$ '+total(taxa).toFixed(2).replace('.',','));
					  });
			    const toast = swal.mixin({
			  		toast: true,
			 		showConfirmButton: false,
			  		timer: 2000
				});
					toast({
	  				type: 'success',
	  				title: 'Item excluido com Sucesso!'
				})
			  }else{
			  	li.find('.qtd').text(qtd +1);
			  }
			});
		}else{
			tot = qtd * val;
			li.find('.qtd').text(qtd);
			li.find('.valor').text("R$ "+tot.toFixed(2).replace('.',','));
			$('#total').text('R$ '+total().toFixed(2).replace('.',','));
			$('#qtd-carrinho').text(parseFloat($('#qtd-carrinho').text()) - 1);
			//var taxa = parseFloat($('#taxa').text().slice(3).replace(',','.'));
			var taxa = 2;
            $('#subtotalentrega').text('R$ '+total(taxa).toFixed(2).replace('.',','));
		}
	return false;
	}	
})(jQuery);

$('#finalizar-pedido').on('click', function(event) {
        event.preventDefault();
        var a = $('#lista-pedidos').find('li.lista');
        //var condicao_entrega = parseFloat($('#qtd-carrinho').text());
        var entrega_endereco = new Pedido.endereco();
        if ($('#whatsapp').val() === "" || $('#proximo').val() === "" || $('#rua').val() === "" || $('#numero').val() === "" || $('#bairro').val() === "" || $('#cliente').val() === "") {
            alertas('campos vazios');
        }else{//verificação campos vazios
        	var valores_campos_endereco = [];
	            valores_campos_endereco.push($('#cliente').val());
				valores_campos_endereco.push($('#rua').val());
				valores_campos_endereco.push($('#numero').val());
				valores_campos_endereco.push($('#bairro').val());
				valores_campos_endereco.push($('#proximo').val());
				valores_campos_endereco.push($('#whatsapp').val());
      			entrega_endereco.set(valores_campos_endereco[0],valores_campos_endereco[1],valores_campos_endereco[2],valores_campos_endereco[3],valores_campos_endereco[4]);
                var lista = [];
                var sublista = [];
                for (var i = 0; i < a.length; i++) {
                    sublista['produto']=$(a[i]).find('.produto').text();
                    sublista['qtd']=$(a[i]).find('.qtd').text();
                    lista.push(sublista);
                    sublista = [];
                }
                sublista['total'] = $('#total').text();
                lista.push(sublista);
                sublista = [];
                var cod = codigo();
                var conteudoWhatsApp = cod;
                var enviaPedidoLista = {};//variavel que armazena o pedido completo
                enviaPedidoLista.codigo=cod;
                var enviaPedido = "";//variavel que armazena o pedido
                var link = "https://api.whatsapp.com/send?phone=5589999332646&text=";
                for (var i = 0; i < lista.length; i++) {
                    if (lista[i].produto !== undefined) {
                        enviaPedido+= lista[i].produto+" - ";
                        }
                    if (lista[i].qtd !== undefined) {
                        enviaPedido+="Qtd: "+lista[i].qtd+" | ";
                    }
                    if (lista[i].total !== undefined) {
                        enviaPedido+= "Total a pagar: "+lista[i].total;
                    }
                }
                link += encodeURIComponent("Código do Pedido: "+conteudoWhatsApp);
                enviaPedidoLista.cliente = valores_campos_endereco[0];//localStorage.getItem('cliente');
                var whatsapp = valores_campos_endereco[5];
                valores_campos_endereco.shift();
                enviaPedidoLista.endereco = valores_campos_endereco.toString();
                enviaPedidoLista.pedido = enviaPedido;
                enviaPedidoLista.data = dataAtual();
                enviaPedidoLista.status ="ABERTO";
                var formapagamento = "dinheiro";
                enviaPedidoLista.pagamento = formapagamento;
                formapagamento = "";
                enviaPedidoLista.status_entregador=whatsapp;
                $.post('/', enviaPedidoLista, function(data, textStatus, xhr) {
		            /*optional stuff to do after success */
		            if (data === "ok") {
		            	$('#endereco').modal('hide');
			            alertas('pedido finalizado');
			            limparTudo();
		            }
		            console.log(data);
		        });
        }
    });
	$("#despachar").on('click', function(event) {
		event.preventDefault();
		var button = $(this).parent().prev();
		var ul = button.find('ul.des-pedido');
		var id = ul.find('li.id').text();
		console.log();
		//var link ="https://api.whatsapp.com/send?phone="+numero_whatsapp+"&text=";
		  var conteudoWhatsApp = "";
		      conteudoWhatsApp+="*NOVA ENTREGA*\n"+"__________________________________"+"\n'";
		      conteudoWhatsApp+="*Cliente* : _"+ul.find('li.cliente').text()+"_\n";
		      conteudoWhatsApp+="*Pedido*:_"+ul.find('li.pedido').text()+"_\n"+"__________________________________"+"\n'"
		      conteudoWhatsApp+="*Endereço* :_"+ul.find('li.endereco').text()+"_";
		      //link += encodeURIComponent(conteudoWhatsApp);
		      //window.open(link,'_blank');
		      
		 $.post('/pedidos/entrega', {id: id}, function(data, textStatus, xhr) {
		 	/*optional stuff to do after success */
		 	if (textStatus === "success") {
		 		alertas("pedido enviado ao entregador");
		 		$('#status_pedido').modal('hide');
		 		window.location.reload();
		 	}
		 	
		 });
		/* Act on the event */
	});
    $('#concluir').on('click', function(event) {//processo de conclusão do pedido
        var a = $('#lista-pedidos').find('li.lista');
        var condicao_entrega = parseFloat($('#qtd-carrinho').text());
        if (a.length !== 0) {
            if (condicao_entrega >= 3) {
                var entrega_endereco = new Pedido.endereco();
                $('#proximo').val(entrega_endereco.get()[4]);
                $('#cliente').val(entrega_endereco.get()[0]);
                $('#rua').val(entrega_endereco.get()[1]);
                $('#numero').val(entrega_endereco.get()[2]);
                $('#bairro').val(entrega_endereco.get()[3]);
                $('#carrinho').modal('hide');
                $('#endereco').modal('show');
            }else{
                alertas('entrega');
            }
        }else{
            swal({
              showConfirmButton: false,
              title: " Adicione Itens ao Carrinho!",
              text: "Obrigado.",
              type: "error",
              timer: 2000,
            });
            $('#carrinho').modal('hide');
        } //fim if
    });
});//fim inicialização
function alertas(tipo){
		if(tipo ==="adiciona item ao carrinho"){
				const toast = swal.mixin({
			  		toast: true,
			 		showConfirmButton: false,
			  		timer: 1500
				});
					toast({
	  				type: 'success',
	  				title: 'Item Adicionado ao Carrinho!'
	  			})
		}else if(tipo === "escolha o complemento"){
				const toast = swal.mixin({
			  		toast: true,
			 		showConfirmButton: false,
			  		timer: 2000
				});
					toast({
	  				type: 'info',
	  				title: 'Escolha um complemento!'
				})
		}else if(tipo === "pedido finalizado"){
				const toast = swal.mixin({
			  		toast: true,
			 		showConfirmButton: false,
			  		timer: 1500
				});
					toast({
	  				type: 'success',
	  				title: 'Pedido enviado com sucesso!'
	  			})
		}else if(tipo === "escolha o espetinho"){
				const toast = swal.mixin({
			  		toast: true,
			 		showConfirmButton: false,
			  		timer: 2000
				});
					toast({
	  				type: 'info',
	  				title: 'Escolha o espetinho!'
				})
		}else if (tipo === "adicione itens no carrinho"){
			swal({
			  showConfirmButton: false,
			  title: " Adicione Itens ao Carrinho!",
			  text: "Obrigado.",
			  type: "error",
			  timer: 2000,
			});
		}else if (tipo === "campos vazios"){
			const toast = swal.mixin({
			  		toast: true,
			 		showConfirmButton: false,
			  		timer: 2000
				});
					toast({
	  				type: 'error',
	  				title: 'Nenhum campo pode ficar vazio!'
				})
		}else if(tipo === "entrega"){
			const toast = swal.mixin({
			  		toast: true,
			 		showConfirmButton: true,
			  		//timer: 2000
				});
					toast({
	  				type: 'info',
	  				title: 'Só entregamos a partir de 3 unidades!'
				})
		}else if(tipo === "pedido enviado ao entregador"){
			const toast = swal.mixin({
			  		toast: true,
			 		showConfirmButton: true,
			  		//timer: 2000
				});
					toast({
	  				type: 'success',
	  				title: 'Pedido enveiado ao entregador com sucesso!'
				})
		}
		else if(tipo === "pedido excluido"){
			const toast = swal.mixin({
			  		toast: true,
			 		showConfirmButton: true,
			  		//timer: 2000
				});
					toast({
	  				type: 'success',
	  				title: 'Pedido excluido com sucesso!'
				})
		}
	}
function total(taxa){//soma todos os valores dos itens da tabela
	var soma = 0;
	var muilt = 0;
	if (taxa) {
		$("li.lista").find('span.valor').each(function(index, el) {
		soma+= parseFloat($(this).text().slice(3).replace(',','.'));
	    });
		return soma + parseFloat(taxa);
	}else{
		$("li.lista").find('span.valor').each(function(index, el) {
		soma+= parseFloat($(this).text().slice(3).replace(',','.'));
	    });
		return soma;
	}
};
function codigo(max){
	max=(!max||max>3)?3:max;
	var codigo='';
	var letras=['w','x','y','z','f','b','c','k','g','b'];
	var numeracao=Math.random();
	var string=String(numeracao);
	var string=string.split('.');
	var numeros=string[1].split('');
	for (var i = 0; i < max; i++) {
		codigo+=numeros[i]+letras[numeros[i]];
	}
	return codigo;   
}
function limparTudo(){
	$('#lista-pedidos').find('li.lista').remove();
	$('#qtd-carrinho').text('0');
	$('#subtotalentrega').text('R$ 0,00');
	$('#total').text('R$ 0,00');
}
function dataAtual(){
	var d = new Date();
	var data = "";
	var dia = d.getDate();
	var mes = d.getMonth() + 1;
	var ano = d.getFullYear();
	var h = d.getHours();
	var s = d.getSeconds();
	var m = d.getMinutes();
	data = dia+"/"+mes+"/"+ano+" "+h+":"+m+":"+s;
	return data;
}
function Entrega(numero_whatsapp){
		  
}