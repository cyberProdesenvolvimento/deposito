$(document).ready(function() {

	$('a.pizza1').click(function(event) {
		/* Quatro extações */
		var text = $(this).text();
		if (text === "G") {
			$('p.tam_textpizza1').text('Tam : G');
			$('#preço_pizza1').text('R$ 40,00');
		}
		if (text === "M") {
			$('p.tam_textpizza1').text('Tam : M');
			$('#preço_pizza1').text('R$ 38,00');
		}
		if (text === "P") {
			$('p.tam_textpizza1').text('Tam : P');
			$('#preço_pizza1').text('R$ 30,00');
		}
		if (text === "GG") {
			$('p.tam_textpizza1').text('Tam : GG');
			$('#preço_pizza1').text('R$ 45,00');
		}

	});
	$('a.pizza2').click(function(event) {
		/* portuguesa */
		var text = $(this).text();
		if (text === "G") {
			$('p.tam_textpizza2').text('Tam : G');
			$('#preço_pizza2').text('R$ 36,00');
		}
		if (text === "M") {
			$('p.tam_textpizza2').text('Tam : M');
			$('#preço_pizza2').text('R$ 30,00');
		}
		if (text === "P") {
			$('p.tam_textpizza2').text('Tam : P');
			$('#preço_pizza2').text('R$ 25,00');
		}
		if (text === "GG") {
			$('p.tam_textpizza2').text('Tam : GG');
			$('#preço_pizza2').text('R$ 40,00');
		}

	});
	$('a.pizza3').click(function(event) {
		/* italiana */
		var text = $(this).text();
		if (text === "G") {
			$('p.tam_textpizza3').text('Tam : G');
			$('#preço_pizza3').text('R$ 40,00');
		}
		if (text === "M") {
			$('p.tam_textpizza3').text('Tam : M');
			$('#preço_pizza3').text('R$ 38,00');
		}
		if (text === "P") {
			$('p.tam_textpizza3').text('Tam : P');
			$('#preço_pizza3').text('R$ 30,00');
		}
		if (text === "GG") {
			$('p.tam_textpizza3').text('Tam : GG');
			$('#preço_pizza3').text('R$ 45,00');
		}

	});
	$('a.pizza4').click(function(event) {
		/* a moda da casa */
		var text = $(this).text();
		if (text === "G") {
			$('p.tam_textpizza4').text('Tam : G');
			$('#preço_pizza4').text('R$ 40,00');
		}
		if (text === "M") {
			$('p.tam_textpizza4').text('Tam : M');
			$('#preço_pizza4').text('R$ 38,00');
		}
		if (text === "P") {
			$('p.tam_textpizza4').text('Tam : P');
			$('#preço_pizza4').text('R$ 30,00');
		}
		if (text === "GG") {
			$('p.tam_textpizza4').text('Tam : GG');
			$('#preço_pizza4').text('R$ 45,00');
		}

	});


	$('.add').click(function(event) {
		/* Act on the event */
		swal({
			  title: "Good job!",
			  text: "Pedido Adicionao",
			  icon: "success",
			  timer: 1000,
			});
	});
});

function ocultar(){
	$('#pedidos').hide();
};