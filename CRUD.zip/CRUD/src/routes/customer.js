const express = require('express');
const router = express.Router();
const customerController = require('../controllers/customerController');

router.get('/', customerController.index);
router.get('/admin', customerController.list);

router.post('/add', customerController.save);
router.get('/delete/:id', customerController.delete); 

router.get('/update/:id', customerController.edit);
router.post('/update/:id', customerController.update);

router.post('/', customerController.inserir); 

router.get('/pedidos', customerController.pedidos);
router.post('/pedidos/', customerController.status);
router.post('/pedidos/excluir', customerController.deletepedido);
router.post('/pedidos/entrega', customerController.entrega);
module.exports = router;