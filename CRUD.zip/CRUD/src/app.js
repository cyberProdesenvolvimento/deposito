const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const alert = require('sweetalert2');
const morgan = require('morgan');
const mysql = require('mysql');
const myConnection = require('express-myconnection');

const app = express();

//importando rotas
const customerRoutes = require('./routes/customer');
//settings
app.set('port', process.env.PORT || 3000);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
// middlewares
app.use(morgan('dev'));
app.use(myConnection(mysql, {
	host: 'localhost',
	user:'admin',
	password:'123456',
	//port:3306,
	database:'db' 
}, 'single'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));
// routes
app.use('/', customerRoutes);
//static files
app.use(express.static(path.join(__dirname, 'public')));


app.listen(app.get('port'), ()=>{
	console.log('servidor rorando na porta 3000');
});